# SpeedFM Premium Android Project

Ez a projekt tartalmazza az alkalmazás forráskódját és a GitHub Actions scriptet az APK fájl automatikus generálásához.
